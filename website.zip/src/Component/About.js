import React from "react";
import "../Styling/App.css";

const About = () => {
  return (
    <div style={{ display: "flex" }}>
      <h1>About Us</h1>
    </div>
  );
};

export default About;
