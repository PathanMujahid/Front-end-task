import React from "react";
import "../Styling/App.css";

const ContactUs = () => {
  return (
    <div>
      <h1>Contact Us</h1>
    </div>
  );
};

export default ContactUs;
